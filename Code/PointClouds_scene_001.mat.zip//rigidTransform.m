function [ output_args ] = rigidTransform( input_args )
%RIGIDTRANSFORM Summary of this function goes here
%   Detailed explanation goes here


end

